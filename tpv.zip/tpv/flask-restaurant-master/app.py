import sys
sys.path.append('C:\\Users\\n128884\\AppData\\Local\\Continuum\\anaconda3\\Lib')

# Flask.
from flask import Flask, render_template, url_for, request, redirect, flash, jsonify
from functools import wraps
app = Flask(__name__)

# SqlAlchemy.
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import update

# Database.
from database_setup import Base, Restaurant, MenuItem, Toppings, User
engine = create_engine('sqlite:///restaurantmenuwithusers.db')
Base.metadata.bind=engine
DBSession = sessionmaker(bind=engine)
session = DBSession()

# Auth.
#from flask import session as login_session
#import random, string
#from oauth2client.client import flow_from_clientsecrets
#from oauth2client.client import FlowExchangeError
#import httplib2
import json
import requests
from flask import make_response

@app.route('/')

# Routing: APP
@app.route('/restaurants')
def showRestaurants():
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    restaurants = session.query(Restaurant).order_by('id desc').all()
    return render_template('_page.html', title='Restaurants', view='showRestaurants', restaurants=restaurants)

@app.route('/restaurants/new', methods=['GET', 'POST'])
def newRestaurant():
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    if request.method == 'POST':
        restaurant = Restaurant(name = request.form['name'].strip(), user_id = 'Admin')
        session.add(restaurant)
        session.commit()
        flash('Restaurant ' + '"' + restaurant.name + '"' + ' created.')
        return redirect(url_for('showRestaurants'))
    else:
        return render_template('_page.html', title='New Restaurant', view='newRestaurant')

@app.route('/restaurants/edit/<int:restaurant_id>', methods=['GET', 'POST'])
def editRestaurant(restaurant_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()


  if request.method == 'POST':
    if request.form['name']:
        restaurant.name = request.form['name'].strip()
    session.add(restaurant)
    session.commit()
    flash('Restaurant ' + '"' + restaurant.name + '"' + ' updated.')
    return redirect(url_for('showRestaurants'))
  else:
    restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()
    return render_template('_page.html', title='Edit Restaurant', view='editRestaurant', restaurant=restaurant)

@app.route('/restaurants/delete/<int:restaurant_id>', methods=['GET', 'POST'])
def deleteRestaurant(restaurant_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()


  if request.method == 'POST':
    session.delete(restaurant)
    session.commit()
    flash('Restaurant ' + '"' + restaurant.name + '"' + ' deleted.')
    return redirect(url_for('showRestaurants'))
  else:
    return render_template('_page.html', title='Delete Restaurant', view='deleteRestaurant', restaurant=restaurant)

@app.route('/restaurants/<int:restaurant_id>')
@app.route('/restaurants/<int:restaurant_id>/menu')
def showMenu(restaurant_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()

  items = session.query(MenuItem).filter_by(restaurant_id=restaurant_id).order_by('id desc')
  return render_template('_page.html', title=restaurant.name, view='showMenu', restaurant=restaurant, items=items)

@app.route('/restaurants/<int:restaurant_id>/menu/new', methods=['GET', 'POST'])
def newMenuItem(restaurant_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()


  if request.method == 'POST':
    newItem = MenuItem(
      name = request.form['name'].strip(),
      description = request.form['description'].strip(),
      course = request.form['course'].strip(),
      price = request.form['price'].strip(),
      restaurant_id = restaurant.id)
    session.add(newItem)
    session.commit()
    flash('Menu item ' + '"' + newItem.name + '"' + ' created.')
    return redirect(url_for('showMenu', restaurant_id=restaurant_id))
  else:
    return render_template('_page.html', title='New Menu Item', view='newMenuItem', restaurant=restaurant)

@app.route('/restaurants/<int:restaurant_id>/menu/edit/<int:menu_item_id>', methods=['GET', 'POST'])
def editMenuItem(restaurant_id, menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()


  item = session.query(MenuItem).filter_by(id=menu_item_id).one()
  if request.method == 'POST':
    item.name = request.form['name'].strip()
    item.description = request.form['description'].strip()
    item.course = request.form['course'].strip()
    item.price = request.form['price'].strip()
    session.add(item)
    session.commit()
    flash('Menu item ' + '"' + item.name + '"' + ' updated.')
    return redirect(url_for('showMenu', restaurant_id=restaurant_id))
  else:
    return render_template('_page.html', title='Edit Menu Item', view='editMenuItem', restaurant=restaurant, item=item)

@app.route('/restaurants/<int:restaurant_id>/menu/delete/<int:menu_item_id>', methods=['GET', 'POST'])
def deleteMenuItem(restaurant_id, menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()
  item = session.query(MenuItem).filter_by(id=menu_item_id).one()
  if request.method == 'POST':
    session.delete(item)
    session.commit()
    flash('Menu item ' + '"' + item.name + '"' + ' deleted.')
    return redirect(url_for('showMenu', restaurant_id=restaurant_id))
  else:
    return render_template('_page.html', title='Delete Menu Item', view='deleteMenuItem', restaurant=restaurant, item=item)

@app.route('/restaurants/<int:restaurant_id>/menu/<int:menu_item_id>')
@app.route('/restaurants/<int:restaurant_id>/menu/<int:menu_item_id>/toppings')
def showToppings(restaurant_id,menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()
  item = session.query(MenuItem).filter_by(id=menu_item_id).one()
  toppings = session.query(Toppings).filter_by(restaurant_id=restaurant_id,menu_id=menu_item_id).order_by('id desc')
  return render_template('_page.html', title=restaurant.name, view='showToppings', restaurant=restaurant, items=item, toppings=toppings)

@app.route('/restaurants/<int:restaurant_id>/menu/<int:menu_item_id>/toppings/new', methods=['GET', 'POST'])
def newItemTopping(restaurant_id,menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()
  item = session.query(MenuItem).filter_by(id=menu_item_id).one()


  if request.method == 'POST':
    newTopping = Toppings(
      name = request.form['name'].strip(),
      description = request.form['description'].strip(),
      course = request.form['course'].strip(),
      price = request.form['price'].strip(),
      restaurant_id = restaurant.id,
      menu_id = item.id)
    session.add(newTopping)
    session.commit()
    flash('Item Topping ' + '"' + newTopping.name + '"' + ' created.')
    return redirect(url_for('showToppings', restaurant_id=restaurant_id, menu_item_id=menu_item_id))
  else:
    return render_template('_page.html', title='New Item Topping', view='newItemTopping', restaurant=restaurant,item=item)

#editar a partir de aquí
######################################
'''

@app.route('/restaurants/<int:restaurant_id>/menu/edit/<int:menu_item_id>', methods=['GET', 'POST'])
def editMenuItem(restaurant_id, menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()


  item = session.query(MenuItem).filter_by(id=menu_item_id).one()
  if request.method == 'POST':
    item.name = request.form['name'].strip()
    item.description = request.form['description'].strip()
    item.course = request.form['course'].strip()
    item.price = request.form['price'].strip()
    session.add(item)
    session.commit()
    flash('Menu item ' + '"' + item.name + '"' + ' updated.')
    return redirect(url_for('showMenu', restaurant_id=restaurant_id))
  else:
    return render_template('_page.html', title='Edit Menu Item', view='editMenuItem', restaurant=restaurant, item=item)

@app.route('/restaurants/<int:restaurant_id>/menu/delete/<int:menu_item_id>', methods=['GET', 'POST'])
def deleteMenuItem(restaurant_id, menu_item_id):
  DBSession = sessionmaker(bind=engine)
  session = DBSession()
  restaurant = session.query(Restaurant).filter_by(id=restaurant_id).one()
  item = session.query(MenuItem).filter_by(id=menu_item_id).one()
  if request.method == 'POST':
    session.delete(item)
    session.commit()
    flash('Menu item ' + '"' + item.name + '"' + ' deleted.')
    return redirect(url_for('showMenu', restaurant_id=restaurant_id))
  else:
    return render_template('_page.html', title='Delete Menu Item', view='deleteMenuItem', restaurant=restaurant, item=item)
'''

# Routing: API-JSON
@app.route('/restaurants/json')
def showRestaurantsJSON():
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    restaurants = session.query(Restaurant).all()
    json = jsonify(Restaurants=[r.serialize for r in restaurants])
    response = make_response(json, 200)
    response.headers['Content-Type'] = 'application/json'
    return response
'''
@app.route('/restaurants/xml')
def showRestaurantsXML():
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    restaurants = session.query(Restaurant).all()
    xml = dicttoxml.dicttoxml([r.serialize for r in restaurants])
    response = make_response(xml, 200)
    response.headers['Content-Type'] = 'application/xml'
    return response
'''

@app.route('/restaurants/<int:restaurant_id>/menu/json')
def restaurantMenuJSON(restaurant_id):
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    items = session.query(MenuItem).filter_by(restaurant_id=restaurant_id)
    json = jsonify(MenuItems=[i.serialize for i in items])
    response = make_response(json, 200)
    response.headers['Content-Type'] = 'application/json'
    return response

'''
@app.route('/restaurants/<int:restaurant_id>/menu/xml')
def restaurantMenuXML(restaurant_id):
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    items = session.query(MenuItem).filter_by(restaurant_id=restaurant_id)
    xml = dicttoxml.dicttoxml([i.serialize for i in items])
    response = make_response(xml, 200)
    response.headers['Content-Type'] = 'application/xml'
    return response
'''

@app.route('/restaurants/<int:restaurant_id>/menu/<int:menu_item_id>/json')
def restaurantMenuItemJSON(restaurant_id, menu_item_id):
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    item = session.query(MenuItem).filter_by(id=menu_item_id).one()
    json = jsonify(Item=[item.serialize])
    response = make_response(json, 200)
    response.headers['Content-Type'] = 'application/json'
    return response
'''
@app.route('/restaurants/<int:restaurant_id>/menu/<int:menu_item_id>/xml')
def restaurantMenuItemXML(restaurant_id, menu_item_id):
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    item = session.query(MenuItem).filter_by(id=menu_item_id).one()
    xml = dicttoxml.dicttoxml([item.serialize])
    response = make_response(xml, 200)
    response.headers['Content-Type'] = 'application/xml'
    return response
'''
# Run app.
if __name__ == '__main__':
  app.secret_key = 'super_secret_key'
  app.debug = True
  app.run(host='0.0.0.0', port=5000)
  #app.run(host='0.0.0.0')
